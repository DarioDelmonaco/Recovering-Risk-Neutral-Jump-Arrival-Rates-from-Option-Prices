function cf=cf_BGR(u,par,t,norm)
%{
Characteristic function of the Bilateral Gamma Ratio (BGR) model.

INPUT:
u: frequencies
par: BGR parameters [bp_n, cp_n, bn_n, cn_n, bp_d, cp_d, bn_d, cn_d]
t: time to maturity
norm: boolean flag for martingale normalization

OUTPUT:
cf: evaluated characteristic function array
%}
cf_u=@(v)cf_BG(v,par(1:4),t,false)./cf_BG(v,par(5:8),t,false); % Ratio of two BG characteristic functions
cf=cf_u(u);
if norm==true
    cf=cf.*exp(-1i*u*log(cf_u(-1i))); % Martingale adjustment
end
end