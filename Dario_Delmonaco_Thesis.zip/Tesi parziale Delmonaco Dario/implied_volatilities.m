function IV=implied_volatilities(k,price,t)
%{
Implied volatilities for normalized OTM options.

INPUT:
k: log(K/F)
price: option prices normalized by B and F
t: maturity

OUTPUT:
IV: implied volatilities array
%}
searching_int=1.5; %fzero settings
warning('off', 'all');
options=optimset('Display', 'off','TolX',1e-8);
IV=zeros(length(k),1);
for i=1:length(k)
    BS_minus_model= @(sigma) options_OTM_norm_Black(k(i),sigma,t)-price(i);%difference between Black prices and market prices
    IV(i)=fzero(BS_minus_model,searching_int,options); %Implied volatilities
end
end