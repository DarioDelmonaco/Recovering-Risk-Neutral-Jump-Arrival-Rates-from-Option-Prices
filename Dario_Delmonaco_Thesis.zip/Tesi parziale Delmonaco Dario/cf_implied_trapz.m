function cf=cf_implied_trapz(price_norm,k,u)
%{
Implied CF from pag.13, equation 20 has been simplified. Here the integral
is tackled with trapz.

INPUT:
price_norm: OTM option prices normalized by B and F
k: log(K/F)
u: frequencies

OUTPUT:
cf: implied characteristic function computed via trapezoidal numerical integration
%}
u=u(:).';
price_norm=price_norm(:);
k=k(:);
cf=1-(u.^2+1i*u).*trapz(k,exp(1i*k*u).*exp(-k).*price_norm,1);
end