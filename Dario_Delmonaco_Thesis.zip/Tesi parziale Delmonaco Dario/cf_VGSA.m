function cf=cf_VGSA(u,par,t,norm)
%{
Characteristic function of the Variance Gamma with Stochastic Arrival (VGSA) model.
Based on Carr, Geman, Madan and Yor (2003) equations.

INPUT:
u: frequencies
par: VGSA parameters [C, G, M, kappa, eta, lambda]
t: time to maturity
norm: boolean flag for martingale normalization

OUTPUT:
cf: evaluated characteristic function array
%}
C=par(1); % Extract parameters from array
G=par(2);
M=par(3);
kappa=par(4);
eta=par(5);
lambda=par(6);

psi_VG=@(v)log((G.*M)./(G.*M+(M-G).*1i.*v+v.^2)); % Lévy exponent of the Variance Gamma with C=1 (Eq. 2.9 at page 350)

calc_A_B=@(psi_val) cir_laplace(psi_val,kappa,eta,lambda,t); % Transform of the stochastic time (CIR) (Formulas at page 352). calc_A_B directly receives the exponent psi_VG(u) instead of (i*u)
[A_u,B_u]=calc_A_B(psi_VG(u));

y0=C; % Initial value of the stochastic clock y(0) = C (Eq. 3.7 at page 354)

log_cf_unnorm=log(A_u)+B_u.*y0; % log(phi) of the CIR process

if norm==true
    psi_minus_i=psi_VG(-1i); % Normalization to prevent static arbitrage (Eq. 4.9 at page 358). Requires evaluating the function at v = -1i
    [A_i,B_i]=calc_A_B(psi_minus_i);

    log_den=log(A_i)+B_i.*y0; % Denominator of the fraction in Eq. 4.9

    cf=exp(log_cf_unnorm-1i.*u.*log_den); % Subtract the exponent of the denominator multiplied by i*u
else
    cf=exp(log_cf_unnorm);
end
end

function [A,B]=cir_laplace(psi_val,kappa,eta,lambda,t)
%{
Original paper formulas for A(t,u) and B(t,u) at page 352.
The CIR equation evaluates phi(u) with input (i*u).
Having defined a generic input psi_val, we replace (i*u) with psi_val.
%}
Gamma=sqrt(kappa^2-2.*lambda^2.*psi_val);

num_A=exp((kappa^2.*eta.*t)./(lambda^2)); % Computation of A(t) via cosh and sinh (page 352)
den_A=(cosh(Gamma.*t./2)+(kappa./Gamma).*sinh(Gamma.*t./2)).^(2.*kappa.*eta./lambda^2);
A=num_A./den_A;

num_B=2.*psi_val; % Computation of B(t) via coth (page 352)
den_B=kappa+Gamma.*coth(Gamma.*t./2);
B=num_B./den_B;
end