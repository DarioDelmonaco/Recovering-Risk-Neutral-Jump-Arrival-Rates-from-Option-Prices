function cf=cf_implied_fft(price_norm,k,sigma_ATM,t,discretization,ATM_regul)
%{
Implied CF from pag.13, equation 20 has been simplified. Here the integral
is tackled with ifft. The peek in k=0 has been tackled by adding and subtracting 
Black prices fixing the volatility at ATM. The continuous derivative factor u.^2+1i*u 
has been substituted by discrete derivative factors to avoid fft noise amplification
due to the u.^2 term.

INPUT:
price_norm: OTM option prices normalized by B and F
k: log-strikes grid
sigma_ATM: ATM implied volatility
t: time to maturity
discretization: boolean flag to enable discrete derivative factors
ATM_regul: boolean flag to enable ATM regulation (adding/subtracting Black prices)

OUTPUT:
cf: implied characteristic function computed via IFFT
%}
dk=k(2)-k(1);
N=length(k);
du=2*pi/(N*dk);
u=(-N/2:N/2-1)*du;
price_norm=price_norm(:).';
new_price_norm=price_norm.*exp(-k);
D1=u;
D2=u.^2;
if discretization
   D1=sin(u.*dk)./dk;                % Approximates u
   D2=2*(1-cos(u.*dk))./(dk.^2);     % Approximates u^2 
end
if ATM_regul
    I=dk*N*fftshift(ifft(ifftshift(new_price_norm-options_OTM_norm_Black(k,sigma_ATM,t).*exp(-k)))); % Integral computed via ifft
    cf_BS=exp(-sigma_ATM^2*t*(u.^2+1i*u)/2);
    cf=cf_BS-(D2+1i*D1).*I;
else
    I=dk*N*fftshift(ifft(ifftshift(new_price_norm))); % Integral computed via ifft 
    cf=1-(D2+1i*D1).*I;
end
end