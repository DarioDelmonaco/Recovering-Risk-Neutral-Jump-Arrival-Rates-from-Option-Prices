function u_cutoff=find_cf_underflow(cf,u)
%{
Finds the frequency at which the characteristic function (CF) reaches machine zero (underflow).

INPUT:
cf: characteristic function evaluated on the frequency grid
u: frequency grid array

OUTPUT:
u_cutoff: first positive frequency where |CF| <= realmin (NaN if not found)
%}
idx_pos=(u>=0);
u_pos=u(idx_pos);
cf_pos=cf(idx_pos);
idx_underflow=find(abs(cf_pos)<=realmin,1,'first'); % find the first index where the CF magnitude drops to or below realmin
if ~isempty(idx_underflow)
    u_cutoff=u_pos(idx_underflow);
    fprintf('The CF reaches machine zero (realmin) at u = %.4f\n',u_cutoff);
else
    u_cutoff=NaN; % return NaN if the cutoff is not found
    disp('The CF never reaches realmin within the provided frequency grid.');
end
end