function cf=cf_BG(u,par,t,norm)
%{
Characteristic function of the Bilateral Gamma (BG) model.

INPUT:
u: frequencies
par: BG parameters [bp, cp, bn, cn]
t: time to maturity
norm: boolean flag for martingale normalization

OUTPUT:
cf: evaluated characteristic function array
%}
bp=par(1);cp=par(2);bn=par(3);cn=par(4); % Extract parameters
cf_u=@(v)(1-1i*bp.*v).^(-cp*t).*(1+1i*bn.*v).^(-cn*t); % Unnormalized characteristic function
cf=cf_u(u);
if norm==true
    cf=cf.*exp(-1i*u*log(cf_u(-1i))); % Martingale adjustment
end
end