function cf=cf_CGMYR(u,par,t,norm)
%{
Characteristic function of the CGMY Ratio (CGMYR) model.

INPUT:
u: frequencies
par: CGMYR parameters (1:6 for numerator, 7:12 for denominator)
t: time to maturity
norm: boolean flag for martingale normalization

OUTPUT:
cf: evaluated characteristic function array
%}
cf_u=@(v)cf_CGMY(v,par(1:6),t,false)./cf_CGMY(v,par(7:12),t,false); % Ratio of two CGMY characteristic functions
cf=cf_u(u);
if norm==true
    cf=cf.*exp(-1i*u*log(cf_u(-1i))); % Martingale adjustment
end
end