function cf=cf_svgcos(u,a,theta,Gamma)
%{
Characteristic function of the Symmetric Variance Gamma multiplied by the cosine 
of the jump size (svgcos) model.

INPUT:
u: frequencies
a: svgcos parameter
theta: svgcos parameter
Gamma: svgcos parameter

OUTPUT:
cf: evaluated characteristic function array
%}
cf=((a^2+theta^2)./sqrt((a^2-theta^2+u.^2).^2+4*a^2*theta^2)).^Gamma;
end