function arr=exact_arrival_rates_CGMY(x,par)
%{
Computes exact arrival rates for the CGMY model.

INPUT:
x: returns grid
par: CGMY parameters [cp, yp, bp, cn, yn, bn]

OUTPUT:
arr: exact arrival rates evaluated on the grid x
%}
cp=par(1); % Extract parameters from the par array
yp=par(2);
bp=par(3);
cn=par(4);
yn=par(5);
bn=par(6);

arr = zeros(size(x));    
idx_p=x>0; 
idx_n=x<0; 
arr(idx_p)=cp.*exp(-x(idx_p)./bp)./(x(idx_p).^(1+yp));
arr(idx_n)=cn.*exp(-abs(x(idx_n))./ bn)./(abs(x(idx_n)).^(1+yn));
end