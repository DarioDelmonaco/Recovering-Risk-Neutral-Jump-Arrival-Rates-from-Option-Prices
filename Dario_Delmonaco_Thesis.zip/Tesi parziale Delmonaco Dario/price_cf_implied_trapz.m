function price=price_cf_implied_trapz(cf,k,alpha,u)
%{
OTM option prices by Carr-Madan formula with damping correction. The integral
is tackled with trapz. ATMF price computed with Lewis formula.

INPUT:
cf: returns CF
k: log-strikes log(K/F)
alpha: lewis damping
u: frequencies

OUTPUT:
price: option prices evaluated on the grid k
%}
k=k(:);
u=u(:).';
damping=1.1;
x=@(v) (1-cf(v))./(v.^2+1i*v);
csi=(x(u-1i*damping)-x(u+1i*damping))/2;
price=real(exp(k)/(2*pi).*trapz(u,exp(-1i*k*u).*csi,2))./sinh(damping*k);
k_is_0=find(k==0);
if ~isempty(k_is_0)
cf_damped=cf(u-(alpha+1)*1i)./((alpha+1i*u).*(1+alpha+1i*u));%price=Nan for k=0 --> lewis formula 
price(k_is_0) = real(trapz(u,cf_damped)/(2*pi));
end
end