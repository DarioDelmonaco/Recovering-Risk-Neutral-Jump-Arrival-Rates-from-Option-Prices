function [den,x_grid]=probability_density(cf,du)
%{
Computes the probability density function from the characteristic function using FFT.

INPUT:
cf: characteristic function evaluated on a frequency grid
du: frequency step size

OUTPUT:
den: probability density function array
x_grid: returns grid corresponding to the density
%}
den=real(ifftshift(fft(fftshift(cf)))*du/(2*pi));
N=length(cf);
dx=2*pi/(N*du);
x_grid=(-N/2:N/2-1)*dx;
end