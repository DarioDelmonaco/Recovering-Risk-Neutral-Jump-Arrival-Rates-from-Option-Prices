function [arr_rate,x,LHS]=arrival_rates(cf,u,t,bw,damping,W)
 %{
Arrival rates computed by derivating tail measures. The left hand side of
eq.24 at pag.17 has been damped to avoid oscillation. The tail measure computed with fft has
been smoothed with gaussian kernel technique before deriving it.

INPUT:
cf: returns CF
u: frequencies 
t: ttm
bw: bandwidth of gaussian kernel smoothing for tail measure
damping: damping parameter for left hand side of eq.24 at pag.17, =0 to switch off
W: Tukey window for left hand side of eq.24 at pag.17, =1 to switch off

OUTPUT:
arr_rate: computed arrival rates
x: returns grid corresponding to the arrival rates
LHS: left hand side of eq.24 at pag.17
 %}
if nargin<6
    W=1;
    if nargin<5
        damping=0;
    end
end

du=u(2)-u(1);
N=length(u);
dx=(2*pi)/(du*N);
x=(-N/2:N/2-1)*dx;
u_is_0=find(u==0,1);

ang=angle(cf); %continuity of the phase from 0
ang(u_is_0:end)=unwrap(ang(u_is_0:end)); %right continuity
ang(u_is_0:-1:1)=unwrap(ang(u_is_0:-1:1));  %left continuity
ang=ang-ang(u_is_0); % ang(0)=0
chi_u=log(abs(cf))+1i*ang; %complex exponential variation
LHS=chi_u./(1i*u); %left hand side of eq.24 at pag.17

if ~isempty(u_is_0) %since LHS(0)=NaN
    % LHS(u_is_0)=(LHS(u_is_0-1)+LHS(u_is_0+1))/2;
    dchi_0=(chi_u(u_is_0+1)-chi_u(u_is_0-1))/(2*du); 
    LHS(u_is_0)=dchi_0/1i; %limit as at pag.17
end

gaussian_damping=exp(-damping*(u.^2));
LHS_damped=LHS.*gaussian_damping.*W; 
LHS_damped(isnan(LHS_damped) | isinf(LHS_damped))=0;
 
% figure
% plot(u,abs(LHS_damped))
% title('LHS')

K_tail=real(fftshift(fft(ifftshift(LHS_damped)))*du/(2*pi)); %tail measure

% figure
% plot(x,K_tail,'b')
% xlim([-0.2,0.2])
% title('K_tail')

K_tail_smoothed=smoothdata(K_tail,'gaussian',bw,'SamplePoints',x);

% figure
% plot(x,K_tail_smoothed,'r')
% xlim([-0.2,0.2])
% title('K_tail smoothed')
dK_tail=gradient(K_tail_smoothed,dx); %derivative of tail measure
arr_rate=-dK_tail/t;
end