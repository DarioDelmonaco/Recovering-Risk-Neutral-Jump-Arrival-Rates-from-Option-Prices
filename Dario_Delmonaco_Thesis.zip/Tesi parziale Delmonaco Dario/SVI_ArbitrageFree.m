function [k,sigma_fit,opt_x,success,fval]=SVI_ArbitrageFree(sigma_mkt,sigma_bid,sigma_ask,k_opt,t,k,constraint)
%{
SVI model calibrated with NO-ARBITRAGE (and optional bid-ask) constraints.

INPUT:
sigma_mkt: market implied volatilities (mid)
sigma_bid: market bid implied volatilities
sigma_ask: market ask implied volatilities
k_opt: market log-strikes
t: time to maturity
k: target evaluation log-strikes grid
constraint: string mode ('static', 'dynamic', 'free')

OUTPUT:
k: output log-strikes grid (empty if calibration fails)
sigma_fit: fitted implied volatilities on the target grid k
opt_x: calibrated SVI parameters [a, b, rho, m, s]
success: boolean flag indicating if the calibration was successful
fval: final objective function value (error)
%}

sigma_mkt=sigma_mkt(:); 
sigma_bid=sigma_bid(:);
sigma_ask=sigma_ask(:);
k_opt=k_opt(:);

use_bidask=true; 

if strcmpi(constraint,'static') %original fixed bid-ask bounds
    sigma_lb=sigma_bid;
    sigma_ub=sigma_ask;
    w_upper_bound=(sigma_ub.^2)*t;
    
elseif strcmpi(constraint,'dynamic') %moving bid-ask bounds window
    spread_vol=sigma_ask-sigma_bid;
    sigma_lb=sigma_mkt-spread_vol/2;
    sigma_ub=sigma_mkt+spread_vol/2;
    w_upper_bound=(sigma_ub.^2)*t;
    
elseif strcmpi(constraint,'free') % no bid-ask constraints
    use_bidask=false; 
    sigma_lb=[]; 
    sigma_ub=[]; 
    w_upper_bound=(sigma_mkt.^2)*t*2; % safety margin to compute the upper bound of 'a'
    
else
    error('Invalid mode. Use ''static'', ''dynamic'' or ''free''.');
end

svi_var=@(x,k)x(1)+x(2)*(x(3)*(k-x(4))+sqrt((k-x(4)).^2+x(5)^2));% x=[a,b,rho,m,s]
obj_fun=@(x)sum((sqrt(max(svi_var(x,k_opt),1e-10)./t)-sigma_mkt).^2);

lb=[1e-5,0.0,-0.99,-0.5,1e-4]; 
ub=[max(w_upper_bound)*2,100.0,0.99,2.0,5.0];

options=optimoptions('fmincon','Display','off','Algorithm','interior-point',... 
    'MaxFunctionEvaluations',5000,...
    'MaxIterations',2000,...
    'ConstraintTolerance',1e-8,...
    'OptimalityTolerance',1e-10,...
    'StepTolerance',1e-12);

k_grid_check=linspace(min(k_opt),max(k_opt),300); 

opt_x=[];
success=false;
fval=NaN; 
x0=lb+(ub-lb).*rand(1,5);

try %to avoid errors stop
    [x_temp,fval_temp,exitflag]=fmincon(obj_fun,x0,[],[],[],[],lb,ub,...
        @(x)svi_constraints(x,k_grid_check,k_opt,sigma_lb,sigma_ub,t,use_bidask),options);
    
    if exitflag>0
        opt_x=x_temp;
        fval=fval_temp; 
        success=true;
    end
catch
end

if ~success
    k=[];sigma_fit=[];
    return; 
end

w_fit=svi_var(opt_x,k); 
sigma_fit=sqrt(max(w_fit,0)/t);
end

function [c,ceq]=svi_constraints(x,k_grid,k_opt,sigma_lb,sigma_ub,t,use_bidask)
    a=x(1);b=x(2);rho=x(3);m=x(4);s=x(5);
    ceq=[]; 
    
    c_var=-(a+b*s*sqrt(1-rho^2)); 
    c_lee_right=b*(1+rho)-2; 
    c_lee_left=b*(1-rho)-2; 
    
    term=sqrt((k_grid-m).^2+s^2);
    w=a+b*(rho*(k_grid-m)+term);
    dw=b*(rho+(k_grid-m)./term);
    d2w=b*(s^2)./(term.^3);
    
    g_k=(1-(k_grid.*dw)./(2.*w)).^2-((dw.^2)./4).*(1./w+0.25)+d2w./2;
    c_butterfly=-g_k; 
    
    if use_bidask
        term_opt=sqrt((k_opt-m).^2+s^2);
        w_fit_opt=a+b*(rho*(k_opt-m)+term_opt);
        sigma_fit_opt=sqrt(max(w_fit_opt,0)/t);
        
        c_bid=sigma_lb-sigma_fit_opt; 
        c_ask=sigma_fit_opt-sigma_ub; 
    else
        c_bid=[];
        c_ask=[];
    end
    
    c=[c_var,c_lee_right,c_lee_left,c_butterfly(:)',c_bid(:)',c_ask(:)'];
end