function cf=cf_trunc_svg(u,a,c)
%{
Characteristic function of the TRUNCATED Symmetric Variance Gamma model.

INPUT:
u: frequencies
a: truncated svg parameter
c: truncated svg parameter

OUTPUT:
cf: evaluated characteristic function array
%}
cf=exp(log(c./(c-1i*u))+log(c./(c+1i*u))-2*(expint((a*(c-1i*u)))-2*expint(c*a)+expint((a*(c+1i*u)))));
end