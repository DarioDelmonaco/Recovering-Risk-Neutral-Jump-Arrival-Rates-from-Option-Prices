function price=price_cf_implied_fft(cf,k,alpha)
%{
OTM option prices by Carr-Madan formula with damping correction. The integral
is tackled with fft. ATMF price computed with Lewis formula.

INPUT:
cf: returns CF
k: log-strikes log(K/F)
alpha: lewis damping

OUTPUT:
price: option prices evaluated on the grid k
%}
N=length(k);
dk=k(2)-k(1);
du=2*pi/(N*dk);
u=[-N/2:N/2-1]*du;
damping=1.1;
x=@(v) (1-cf(v))./(v.^2+1i*v);
csi=(x(u-1i*damping)-x(u+1i*damping))/2;
price=real(exp(k)/(2*pi)*du.*fftshift(fft(ifftshift(csi))))./sinh(damping*k);

cf_damped=cf(u-(alpha+1)*1i)./((alpha+1i*u).*(1+alpha+1i*u));%price=Nan for k=0 --> lewis formula 
price(N/2+1) = real(du*sum(cf_damped)/(2*pi));
end