function res=obj_free(par,k,t,u,mkt_prices,model_name)
%{
Objective function for unconstrained least squares optimization.

INPUT:
par: model parameters
k: log-strikes grid
t: time to maturity
u: frequencies
mkt_prices: market option prices
model_name: string specifying the model ('BG', 'CGMY', 'BGR', 'CGMYR')

OUTPUT:
res: residuals array between model prices and market prices
%}
switch model_name % Select the vectorized CF and the correct damping parameter
    case 'BG'
        cf_handle=@(v)cf_BG(v,par,t,true);
        damping=1/(2*par(1)); % bp = par(1)
    case 'CGMY'
        cf_handle=@(v)cf_CGMY(v,par,t,true);
        damping=1/(2*par(3)); % bp = par(3)
    case 'BGR'
        cf_handle=@(v)cf_BGR(v,par,t,true);
        damping=1/(2*par(1)); % bpu = par(1)
    case 'CGMYR'
        cf_handle=@(v)cf_CGMYR(v,par,t,true);
        damping=1/(2*par(3)); % bpu = par(3)
    otherwise
        error('Model not recognized');
end

mod_prices=price_cf_implied_trapz(cf_handle,k,damping,u); 

if any(isnan(mod_prices))||any(isinf(mod_prices))||~isreal(mod_prices) % Handling NaN/Inf/Imaginary numbers
    res=1e5*ones(size(mkt_prices)); 
    return; 
end

res=mod_prices(:)-mkt_prices(:); % Return direct residuals for least squares minimization
end