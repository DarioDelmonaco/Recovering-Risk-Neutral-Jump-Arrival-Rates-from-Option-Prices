function W=tukey_wdw(u,u_start,u_end)
%{
Generates a Tukey window (tapered cosine window) for filtering.

INPUT:
u: frequency array
u_start: frequency where the tapering begins
u_end: frequency where the window drops to zero

OUTPUT:
W: computed Tukey window evaluated on the grid u
%}
W=zeros(size(u)); 
idx_pass=abs(u)<=u_start; %identify indices for the flat passband region
W(idx_pass)=1; 
idx_taper=abs(u)>u_start&abs(u)<=u_end; %identify indices for the tapered cosine region
W(idx_taper)=0.5*(1+cos(pi*(abs(u(idx_taper))-u_start)/(u_end-u_start))); 
end