function cf=cf_CGMY(u,par,t,norm)
%{
Characteristic function of the CGMY model.

INPUT:
u: frequencies
par: CGMY parameters [cp, yp, bp, cn, yn, bn]
t: time to maturity
norm: boolean flag for martingale normalization

OUTPUT:
cf: evaluated characteristic function array
%}
cp=par(1);yp=par(2);bp=par(3); % Extract parameters
cn=par(4);yn=par(5);bn=par(6);
cf_u=@(v)exp(t*(cp*gamma(-yp).*(((1/bp-1i*v).^yp)-bp.^(-yp))+... % Unnormalized characteristic function
                     cn*gamma(-yn).*(((1/bn+1i*v).^yn)-bn.^(-yn))));
cf=cf_u(u);
if norm==true
    cf=cf.*exp(-1i*u*log(cf_u(-1i))); % Martingale adjustment
end
end