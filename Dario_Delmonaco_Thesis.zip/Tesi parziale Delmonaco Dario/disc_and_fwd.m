function [B,F]=disc_and_fwd(K,put,call,t)
%{
Discount Factor and Forward computed exploiting put-call parity. B is
computed via OLS regression of the synthetic forward; F is calibrated by finding the 
root that minimizes the difference between the implied volatilities (the intercepts) at k=0,
computed from the interpolation lines of the two closest OTM Put and Call options.

INPUT:
K: strikes
put: OTM put option prices
call: OTM call option prices
t: maturity

OUTPUT:
B: discount factor
F: forward price
%}
G=call-put;
OLS_coeff=polyfit(K,G,1);
slope=OLS_coeff(1);
intercept=OLS_coeff(2);
B=-slope; %OLS
F_guess=intercept/B; %OLS 

idx_put_OTM=find(K<F_guess,2,'last'); %indexes of closest pair of put strikes from 0
K_put_OTM=K(idx_put_OTM);
put_OTM=put(idx_put_OTM);

idx_call_OTM=find(K>F_guess,2,'first'); %indexes of closest pair of call strikes from 0
K_call_OTM=K(idx_call_OTM);
call_OTM=call(idx_call_OTM);

options=optimset('Display','off');
obj_fun=@(fwd) IV_dist(fwd,K_put_OTM,put_OTM,K_call_OTM,call_OTM,t,B);
F=fzero(obj_fun,F_guess,options);
end

function dist=IV_dist(F,K_put_OTM,put_OTM,K_call_OTM,call_OTM,t,B)
%{
Difference between the implied volatilities (the intercepts) at k=0,
computed from the interpolation lines of the two closest OTM Put and Call options.
F: forward
put_OTM,call_OTM: pairs of OTM option prices
K_put_OTM,K_call_OTM: pairs of strikes
t: maturity
B: discount factor
%}
sigma_guess=1.5;
options=optimset('Display','off','TolX',1e-8);

IV_put=zeros(2,1);
obj_fun_put1= @(sigma) options_OTM_norm_Black(log(K_put_OTM(1)/F),sigma,t)-put_OTM(1)/(F*B);
IV_put(1)=fzero(obj_fun_put1 ,sigma_guess,options);
obj_fun_put2= @(sigma) options_OTM_norm_Black(log(K_put_OTM(2)/F),sigma,t)-put_OTM(2)/(F*B);
IV_put(2)=fzero(obj_fun_put2 ,sigma_guess,options);

IV_call=zeros(2,1);
obj_fun_call1= @(sigma) options_OTM_norm_Black(log(K_call_OTM(1)/F),sigma,t)-call_OTM(1)/(F*B);
IV_call(1)=fzero(obj_fun_call1 ,sigma_guess,options);
obj_fun_call2= @(sigma) options_OTM_norm_Black(log(K_call_OTM(2)/F),sigma,t)-call_OTM(2)/(F*B);
IV_call(2)=fzero(obj_fun_call2 ,sigma_guess,options);

k_put_OTM=log(K_put_OTM/F);
k_call_OTM=log(K_call_OTM/F);

put_coeff=polyfit(k_put_OTM,IV_put,1);
call_coeff=polyfit(k_call_OTM,IV_call,1);

q_put=put_coeff(2);
q_call=call_coeff(2);

dist=q_put-q_call;
end