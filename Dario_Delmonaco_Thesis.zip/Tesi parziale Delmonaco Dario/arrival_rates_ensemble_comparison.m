function [arr_rates_ensemble,x,best_arr_rate]=arrival_rates_ensemble_comparison(CF_complex_ensemble,best_CF,u,t,bw,damping,W,uc,title_str,cf_exact)
%{
Computes and compares the Arrival Rates and LHS for an ensemble of Characteristic Functions.

INPUT:
CF_complex_ensemble: matrix containing the complex CFs [n_curves x N]
best_CF: the characteristic function of the best SVI fit (array)
u: grid of frequencies
t: time to maturity
bw: bandwidth for the Gaussian kernel (arrival rates smoothing)
damping: damping parameter to attenuate high-frequency oscillations
W: Tukey window array (or scalar 1 if off)
uc: divergence cutoff frequency (used only for plot labeling)
title_str: string to use as the base title for the generated plots
cf_exact_BG: (Optional) Exact BG characteristic function for LHS comparison

OUTPUT:
arr_rates_ensemble: matrix of simulated arrival rates
x: returns grid corresponding to the arrival rates
best_arr_rate: arrival rates array corresponding to the best CF
%}

    [valid_count,~]=size(CF_complex_ensemble);

    [~,x,~]=arrival_rates(CF_complex_ensemble(1,:),u,t,bw,damping,W);
    arr_rates_ensemble=zeros(valid_count,length(x));

    fig_arr=figure('Name', sprintf('%s - Arrival Rates Ensemble', title_str));
    hold on
    grid on
    
    fig_lhs=figure('Name', sprintf('%s - |LHS| Ensemble', title_str));
    hold on
    grid on
    plot(NaN, NaN, 'Color', [0.4, 0.4, 1], 'LineWidth', 2, 'DisplayName', 'LHS raw ensemble')
    plot(NaN, NaN, 'Color', [1, 0.5, 0], 'LineWidth', 2, 'DisplayName', 'LHS damped ensemble');

    for i=1:valid_count % Compute and plot arrival rates for all curves in the ensemble 
        [arr_rate,~,LHS_val]=arrival_rates(CF_complex_ensemble(i,:),u,t,bw,damping,W);
        arr_rates_ensemble(i,:)=arr_rate;
        
        figure(fig_arr)
        plot(x,abs(x).*arr_rate,'Color',[0.4,0.4,0.4,0.6],'LineWidth',1,'HandleVisibility','off')
        
        figure(fig_lhs);
        plot(u,abs(LHS_val),'Color',[0.4,0.4,1,0.3],'LineWidth',1,'HandleVisibility','off')
        hold on
        plot(u,abs(LHS_val.*W.*exp(-damping*u.^2)),'Color', [1, 0.5, 0],'LineWidth',1,'HandleVisibility','off')
    end
    
    [best_arr_rate,~,best_LHS]=arrival_rates(best_CF,u,t,bw,damping,W); % Compute and highlight the arrival rates for the Best CF

    figure(fig_arr)
    plot(x,abs(x).*best_arr_rate,'b-','LineWidth',0.5,'DisplayName','Best SVI Fit')
    title(sprintf('%s - Arrival Rates Ensemble\n(bw=%.2e, damping=%.2e, uc=%.2e)',title_str,bw,damping,uc))
    xlabel('x') 
    ylabel('Arrival Rates * |x|')
    xlim([-0.05,0.05])
    ylim([-10,100])
    legend('Location','best')
    
    figure(fig_lhs);
    plot(u,abs(best_LHS),'r-','LineWidth',2,'DisplayName','Best SVI Fit |LHS|')
    
    if nargin>=10 && (strcmp(title_str,'Synthetic BG') || strcmp(title_str,'Synthetic CGMY')) && ~isempty(cf_exact) % Add exact BG LHS if provided
        [~,~,exact_LHS]=arrival_rates(cf_exact,u,t,bw,damping,W);
        plot(u,abs(exact_LHS),'k--','LineWidth',2,'DisplayName','Exact cf |LHS|')
    end
  
    if ~isempty(uc) && ~isnan(uc)
        xline(uc, 'g--', 'LineWidth', 2, 'DisplayName', sprintf('u_c (Cutoff) = %.1f', uc));
    end
    
    title(sprintf('%s - |LHS| Ensemble Comparison\n(damping=%.2e, uc=%.2e)',title_str,damping,uc))
    xlabel('u') 
    ylabel('|LHS|')
    xlim([0,10000])
    legend('Location','best')

    figure(fig_arr)
end