function price=options_OTM_norm_Black(k,sigma,t)
%{
Black OTM option prices normalized by B and F.

INPUT:
k: log-strikes log(K/F)
sigma: volatility
t: maturity

OUTPUT:
price: normalized OTM option prices (put for k<=0, call for k>0)
%}
k = k(:).';
sigma=sigma(:).';
d1=(-k+sigma.^2*t/2)./(sigma*sqrt(t));
d2=d1-sigma*sqrt(t);
put=(exp(k).*normcdf(-d2)-normcdf(-d1)).*(k<=0);
call=(normcdf(d1)-exp(k).*normcdf(d2)).*(k>0);
price=put+call;
end