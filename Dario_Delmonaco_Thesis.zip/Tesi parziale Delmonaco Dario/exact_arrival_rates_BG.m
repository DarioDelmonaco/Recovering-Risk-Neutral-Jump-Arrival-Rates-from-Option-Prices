function arr=exact_arrival_rates_BG(x,par)
%{
Computes exact arrival rates for the Bilateral Gamma (BG) model.

INPUT:
x: returns grid
par: BG parameters [bp, cp, bn, cn]

OUTPUT:
arr: exact arrival rates evaluated on the grid x
%}
bp=par(1); % Extract parameters from the par array
cp=par(2);
bn=par(3);
cn=par(4);

arr=(x>0).*cp.*exp(-x./bp)./max(x,realmin)+...
    (x<0).*cn.*exp(-abs(x)./bn)./max(abs(x),realmin);
end