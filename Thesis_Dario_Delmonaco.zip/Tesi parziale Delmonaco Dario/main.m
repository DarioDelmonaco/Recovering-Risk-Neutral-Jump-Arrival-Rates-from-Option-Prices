%% DARIO DELMONACO (10679120) THESIS: "RISK NEUTRAL JUMP ARRIVAL RATES IMPLIED IN OPTION PRICES AND THEIR MODELS"
%% RECOVERY FOR A BILATERAL GAMMA TEST CASE
clc
clear
close all

bp=0.04228379; %BG parameters
cp=62.162294;
bn=0.3255456;
cn=3.7248332;
t=0.03561643;
p_plus=1/bp; %upper pole
alpha=p_plus/2; %lewis optimal damping parameter 
cf_BG_nrm=@(u) cf_BG(u,[bp,cp,bn,cn],t,true);%cf for Y=log(S/F), martingale
N=2^16;
dk=2e-3; %step size of k=log(K/F)
k=(-N/2:N/2-1)*dk; 

options_norm=price_cf_implied_fft(cf_BG_nrm,k,alpha); %OTM option prices 

n_coarse=20; %skipped points between 2 consecutive included points +1
width_coarse=6; %included points for each side wrt k=0
if 2*n_coarse*width_coarse+1>N 
    error('Subinterval out of range.')
end
idx_k_coarse=N/2+1-(n_coarse*width_coarse):n_coarse:N/2+1+(n_coarse*width_coarse);
k_coarse=k(idx_k_coarse); %coarse set of k
options_coarse=options_norm(idx_k_coarse);
IV=implied_volatilities(k_coarse,options_coarse,t);

figure
F=1150; %fictitious
plot(F*exp(k_coarse),IV,'.r','MarkerSize',25)
hold on

n_int=1; %skipped points between 2 consecutive included points +1
width_int=10000; %included points for each side wrt k=0
if 2*n_int*width_int+1>N 
    error('Subinterval out of range.')
end
idx_k_int=N/2+1-(n_int*width_int):n_int:N/2+1+(n_int*width_int);
k_int=k(idx_k_int); %interpolation+extrapolation set of k
IV_int= interp1(k_coarse, IV, k_int, 'linear','extrap'); %linearly interpolated and extrapolated IV

plot(F*exp(k_int),IV_int,'b','LineWidth',3)
xlim([700,1700])
title('Bilateral Gamma implied volatilities and their interpolations and extrapolation.')
legend('BG model IV','Interpolated IV')
xlabel('Strike')
ylabel('IV')

price_opt_int= options_OTM_norm_Black(k_int,IV_int,t); %Black prices implied by interpolated and extrapolated IV

figure
plot(F*exp(k),options_norm,'r','LineWidth',10)
hold on
plot(F*exp(k_int),price_opt_int,'b','LineWidth',3)
plot(F*exp(k_coarse),options_norm(idx_k_coarse),'ok','MarkerSize',20,'LineWidth',4)
xline(0,'g--','ATMF');
xlim([700,1700])
title('Bilateral Gamma prices and associated implied volatility and interpolated and extrapolated prices.')
legend('Prices from interpolated volatilities', 'BG model prices','BG model prices on the chosen coarse set')
xlabel('Strikes')
ylabel('Option Price')
%%
u_rng= linspace(0.75,1.25,1e3); %frequencies valuation interval
cf_imp=cf_implied_trapz(price_opt_int,k_int,-1i*u_rng); %implied CF valuated in u_rng
exact_cf=cf_BG_nrm(-1i*u_rng); %exact CF valuated in u_rng

figure
plot(u_rng,log(abs(exact_cf)),'r','LineWidth',3)
hold on
plot(u_rng,log(abs(cf_imp)),'k--','MarkerSize',10,'LineWidth',3)
title('Comparison of Log Characteristic Functions.')
legend('Exact BG model prices logCF', 'Interpolated volatility prices logCF','Location','best')
xlabel('u')
ylabel('log|CF|')
%% RECOVERING ARRIVAL RATES FROM OPTION PRICES 
clear 
%PUT_all=readtable("Put02_10mat7.xlsx"); %maturity 7dd
%CALL_all=readtable("Call02_10mat7.xlsx");
%PUT_all=readtable("Put02_10mat10.xlsx"); %maturity 10dd
%CALL_all=readtable("Call02_10mat10.xlsx");
PUT_all=readtable("Put02_10mat11.xlsx"); %maturity 11dd
CALL_all=readtable("Call02_10mat11.xlsx");
%PUT_all=readtable("Put02_11mat11.xlsx",'VariableNamingRule','preserve'); %maturity 11dd
%CALL_all=readtable("Call02_11mat11.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put03_11mat14.xlsx",'VariableNamingRule','preserve'); %maturity 14dd
%CALL_all=readtable("Call03_11mat14.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put16_11mat9.xlsx",'VariableNamingRule','preserve'); %maturity 9dd
%CALL_all=readtable("Call16_11mat9.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put17_11mat7.xlsx",'VariableNamingRule','preserve'); %maturity 7dd
%CALL_all=readtable("Call17_11mat7.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put17_11mat8.xlsx",'VariableNamingRule','preserve'); %maturity 8dd
%CALL_all=readtable("Call17_11mat8.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put17_11mat10.xlsx",'VariableNamingRule','preserve'); %maturity 10dd
%CALL_all=readtable("Call17_11mat10.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put17_11mat13.xlsx",'VariableNamingRule','preserve'); %maturity 13dd
%CALL_all=readtable("Call17_11mat13.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put17_11mat14.xlsx",'VariableNamingRule','preserve'); %maturity 14dd
%CALL_all=readtable("Call17_11mat14.xlsx",'VariableNamingRule','preserve');

cleanCol=@(x)str2double(strrep(strrep(string(x),',',''),'-','NaN'));
PUT_all.Bid=cleanCol(PUT_all.Bid);
PUT_all.Ask=cleanCol(PUT_all.Ask);
PUT_all.Strike=cleanCol(PUT_all.Strike);
PUT_all.Volume=cleanCol(PUT_all.Volume);
CALL_all.Bid=cleanCol(CALL_all.Bid);
CALL_all.Ask=cleanCol(CALL_all.Ask);
CALL_all.Strike=cleanCol(CALL_all.Strike);
CALL_all.Volume=cleanCol(CALL_all.Volume);

PUT_all=sortrows(PUT_all,'Strike','ascend');
CALL_all=sortrows(CALL_all,'Strike','ascend');

max_rel_spread=0.8; 
mid_put_all=(PUT_all.Bid+PUT_all.Ask)/2;
spread_put=PUT_all.Ask-PUT_all.Bid;
cond_put=(PUT_all.Volume>20)&(PUT_all.Bid>0)&... %try to set Volume>lower value if it gives error
    (PUT_all.Ask>PUT_all.Bid)&((spread_put./mid_put_all)<max_rel_spread);%filtering wrt volume and bidask
PUT=PUT_all(cond_put,:);
mid_call_all=(CALL_all.Bid+CALL_all.Ask)/2;
spread_call=CALL_all.Ask-CALL_all.Bid;
cond_call=(CALL_all.Volume>20)&(CALL_all.Bid>0)&... %try to set Volume>lower value if it gives error
    (CALL_all.Ask>CALL_all.Bid)&((spread_call./mid_call_all)<max_rel_spread);
CALL=CALL_all(cond_call,:);

[K_cntr,idx_CALL,idx_PUT]=intersect(CALL.Strike,PUT.Strike,'sorted');%indexes of strikes in both Call and Put tables
PUT_cntr=PUT(idx_PUT,:); 
CALL_cntr=CALL(idx_CALL,:);
put_mid_cntr=(PUT_cntr.Bid+PUT_cntr.Ask)/2;  %mid price
call_mid_cntr=(CALL_cntr.Bid+CALL_cntr.Ask)/2;
t=CALL_all.Maturity(1)/365; %ttm
[B,F]=disc_and_fwd(K_cntr,put_mid_cntr,call_mid_cntr,t); %B:discount factor, F:forward

PUT_OTM=PUT(PUT.Strike<=F,:); %OTM wrt F filtering
CALL_OTM=CALL(CALL.Strike>=F,:);
k_put=log(PUT_OTM.Strike/F);
k_call=log(CALL_OTM.Strike/F);
k_opt=[k_put;k_call]; %log(strike/F)
call_ask=CALL_OTM.Ask/(B*F);
call_bid=CALL_OTM.Bid/(B*F);
put_ask=PUT_OTM.Ask/(B*F);
put_bid=PUT_OTM.Bid/(B*F);
options_ask=[put_ask;call_ask];
options_bid=[put_bid;call_bid];
options_mid=(options_bid+options_ask)/2;%mid price normalized wrt B and F

N=2^22;          
du=0.1;          
u=(-N/2:N/2-1)*du;
u_max=du*N/2;
dk=2*pi/(N*du);
k_max=dk*N/2;
k=(-N/2:N/2-1)*dk;
%% 
%BG calibration 
rng(1)
param_BG0=[0.04,62.16,0.32,3.72];%[bp,cp,bn,cn];
lb_BG = [1e-3, 0.1, 1e-2, 0.1];
ub_BG = [0.5, 150, 0.8, 150];
u_cal=-1e3:1e-1:1e3;
bw=10^(ceil(log10(dk))); %to ensure bw>dk
n_starts=5; %number of starting points for evaluation
bidask=false; % ==true if with bid-ask spread constraints, ==false if NOT
[prices_BG,cf_BG_cal,arr_rate_BG,x,exact_arr_rate_BG,opt_param_BG]=...
    BG_calibration(options_mid,options_bid,options_ask,k_opt,t,param_BG0,lb_BG,ub_BG,u_cal,u,bw,n_starts,bidask); %calibration of BG model
RMSE_BG = sqrt(mean((prices_BG(:)-options_mid(:)).^2));
fprintf('Final fitting RMSE: %.4e\n',RMSE_BG);
%%
%VGSA calibration
rng(1)
param_VGSA0 = [19.14, 15.75, 38.69, 2.18, 5.71, 5.67]; %(C, G, M, kappa, eta, lambda)
lb_VGSA = [1,   1,   1.01, 0.1, 0.1, 0.1];
ub_VGSA = [100, 100, 1000,  20,  20,  20];
u_cal=-1e3:1e-1:1e3;
alpha_VGSA = 1.1; 
bw= 10^(ceil(log10(dk))); %to ensure bw>dk
n_starts=5; %number of starting points for evaluation
bidask=false; % ==true if with bid-ask spread constraints, ==false if NOT
[prices_VGSA,cf_VGSA_cal,arr_rate_VGSA,x]=VGSA_calibration(options_mid,options_bid,options_ask,k_opt,t,param_VGSA0,lb_VGSA,ub_VGSA,u_cal,u,bw,alpha_VGSA,n_starts,bidask);
RMSE_VGSA = sqrt(mean((prices_VGSA(:)-options_mid(:)).^2));
fprintf('Final fitting RMSE: %.4e\n', RMSE_VGSA);
%% 
%CGMY calibration 
rng(1)
param_CGMY0 = [1.0, 0.5, 0.1, 1.0, 0.5, 10.0];%[cp,yp,bp,cn,yn,bn];
lb_CGMY = [1e-3, 1e-3, 1e-5, 1e-3, 1e-3, 1e-3];
ub_CGMY = [150.0, 1.99, 0.95, 150.0, 1.99, 150.0];
u_cal=-1e3:1e-1:1e3;
bw=10^(ceil(log10(dk))); %to ensure bw>dk
n_starts=5; %number of starting points for evaluation, it could take much time
bidask=false; % ==true if with bid-ask spread constraints, ==false if NOT
[prices_CGMY,cf_CGMY_cal,arr_rate_CGMY,x,exact_arr_rate_CGMY, opt_param_CGMY]=...
    CGMY_calibration(options_mid,options_bid,options_ask,k_opt,t,param_CGMY0,lb_CGMY,ub_CGMY,u_cal,u,bw,n_starts,bidask); %calibration of CGMY model
RMSE_CGMY = sqrt(mean((prices_CGMY(:)-options_mid(:)).^2));
fprintf('Final fitting RMSE: %.4e\n',RMSE_CGMY);
%%
%arrival rates comparison
figure
plot(x,abs(x).*exact_arr_rate_BG,'r','LineWidth',5,'DisplayName','Exact formula')
hold on 
plot(x,abs(x).*arr_rate_BG,'g','LineWidth',2,'DisplayName','Implied from exact CF')
legend
xlim([-0.05,0.05])
ylim([-50,200])
title('BG Arrival Rates')
xlabel('x') 
ylabel('Arrival Rates * |x|')

figure
plot(x,abs(x).*exact_arr_rate_CGMY,'r','LineWidth',3,'DisplayName','Exact formula')
hold on 
plot(x,abs(x).*arr_rate_CGMY,'g','DisplayName','Implied from exact CF')
legend
xlim([-0.05,0.05])
ylim([-50,200])
title('CGMY Arrival Rates')
xlabel('x') 
ylabel('Arrival Rates * |x|')

figure
bw=10^(ceil(log10(dk))); %to ensure bw>dk
arr_rate_CGMY_infvar=arrival_rates_inf(cf_CGMY_cal,u,t,bw);
plot(x,abs(x).*exact_arr_rate_CGMY,'r','LineWidth',3,'DisplayName','Exact formula')
hold on 
plot(x,abs(x).*arr_rate_CGMY_infvar,'g','DisplayName','Implied from exact CF with algorithm for infinite variation ')
legend('Location','best')
xlim([-0.05,0.05])
ylim([-50,200])
title('CGMY Arrival Rates, Infinite Variation Algorithm')
xlabel('x') 
ylabel('Arrival Rates * |x|')
%% 
%underflow
u_0m_BG=find_cf_underflow(cf_BG_cal,u);
u_0m_CGMY=find_cf_underflow(cf_CGMY_cal,u);
figure
plot(u,log(abs(cf_BG_cal)),'r','LineWidth',2,'DisplayName','BG')
hold on 
plot(u,log(abs(cf_CGMY_cal)),'b','LineWidth',2,'DisplayName','CGMY')
legend
ylim([-50,2])
title('Modulus decay of Characteristic Functions')
xlabel('u') 
ylabel('log|cf|')
%%
%implied volatilities
IV_BG=implied_volatilities(k_opt,prices_BG,t);
IV_CGMY=implied_volatilities(k_opt,prices_CGMY,t); 
IV_mid=implied_volatilities(k_opt,options_mid,t);
IV_bid=implied_volatilities(k_opt,options_bid,t);
IV_ask=implied_volatilities(k_opt,options_ask,t);
IV_VGSA=implied_volatilities(k_opt,prices_VGSA,t);

figure
hold on
plot(k_opt,IV_ask,'^','MarkerSize',3,'LineWidth',4)
plot(k_opt,IV_bid,'v','MarkerSize',3,'LineWidth',4)
plot(k_opt,IV_mid,'*','MarkerSize',5,'LineWidth',4)
plot(k_opt,IV_BG,'o','MarkerSize',3,'LineWidth',4)
plot(k_opt,IV_VGSA,'o','MarkerSize',3,'LineWidth',4)
plot(k_opt,IV_CGMY,'o','MarkerSize',3,'LineWidth',4)
title('Implied Volatilities')
xlabel('k')
ylabel('IV')
legend('IV ask','IV bid','IV mid','IV BG','IV VGSA', 'IV CGMY')
%% 
%linear extrapolation and interpolation --> too noisy
IV_lin_synt_BG=interp1(k_opt,IV_BG,k,'linear','extrap');

figure
plot(k,IV_lin_synt_BG,'LineWidth',3,'DisplayName','Linearly extrapolated IV')
title('Linearly interpolated and extrapolated IV')
hold on
plot(k_opt,IV_BG,'ro','MarkerSize',10,'LineWidth',3,'DisplayName','Original BG IV')
xlim([-0.1,0.1])
xlabel('k')
ylabel('IV')
legend

price_BG_lin=options_OTM_norm_Black(k,IV_lin_synt_BG,t);
IV_ATM_lin_synt_BG=IV_lin_synt_BG(N/2+1);
cf_imp_lin_synt_BG=cf_implied_fft(price_BG_lin,k,IV_ATM_lin_synt_BG,t,false ,false);

figure
plot(u,abs(cf_imp_lin_synt_BG),'DisplayName','linearly extrapolated IV CF')
title('Linearly interpolated and extrapolated IV |CF| and BG |CF|')
hold on
plot(u,abs(cf_BG_cal),'r','LineWidth',2,'DisplayName','exact BG CF')
xlim([-20,20])
ylim([0,10])
xlabel('u')
ylabel('|CF|')
legend
%% 
%not regularized case -- mkt
IV_mid=implied_volatilities(k_opt,options_mid,t);
IV_lin_mkt=interp1(k_opt,IV_mid,k,'linear','extrap');
options_mid_grid=options_OTM_norm_Black(k,IV_lin_mkt,t);
cf_imp_mkt=cf_implied_fft(options_mid_grid,k,[],t,false,false);
bw= 10^(ceil(log10(dk))); %to ensure bw>dk
[arr_rate_mkt_lin,x]=arrival_rates(cf_imp_mkt,u,t,bw);
figure
plot(x,arr_rate_mkt_lin)
xlim([-0.05,0.05])
ylim([-1000,1000])
title('Arrival Rates')
xlabel('x') 
ylabel('Arrival Rates * |x|')
%% 
%random prices in bidask spread
n_curves=5;
spread = options_ask(:)-options_bid(:);
rng(2)
noise=(rand(length(spread),n_curves)-0.5).*spread;
options_rand_synt_BG = max(prices_BG(:)+noise, 1e-6);%moving bidask spread with center in the calibrated prices (for synthetic)
options_rand_synt_CGMY = max(prices_CGMY(:)+noise, 1e-6); %moving bidask spread with center in the calibrated prices (for synthetic)
options_rand_mkt=options_bid+rand(length(options_bid),n_curves).*spread; %real bidask limits (for mkt)
%%
%SYNTHETIC BG-- extra/interpolation with SVI of the random prices, extraction
%of the best RMSE curve CF and prices. Extraction of cutoff frequency
rng(1)
std_cut = 0.1;           
err_threshold = 1e-1;  
max_iter=50;
[uc_synt_BG, CF_ensemble_svi_synt_BG, cf_best_svi_synt_BG, IV_best_svi_synt_BG,prices_best_svi_synt_BG] = ...
    svi_cf_ensemble_divergence(options_rand_synt_BG, k_opt, t, k, std_cut, err_threshold,max_iter,'Synthetic BG');
%% 
%SVI prices
figure
plot(k,prices_best_svi_synt_BG,'LineWidth',1.5)
title('SVI Calibration Prices')
xlabel('k')
ylabel('pices')
xlim([-2,2])
ylim([-0.0001,0.01])
%%
%SYNTHETIC CGMY -- extra/interpolation with SVI of the random prices, extraction
%of the best RMSE curve CF and prices. Extraction of cutoff frequency
rng(1)
std_cut = 0.1;           
err_threshold = 1e-1;  
max_iter=50;
[uc_synt_CGMY, CF_ensemble_svi_synt_CGMY, cf_best_svi_synt_CGMY, IV_best_svi_synt_CGMY, prices_best_svi_synt_CGMY] = ...
    svi_cf_ensemble_divergence(options_rand_synt_CGMY, k_opt, t, k, std_cut, err_threshold,max_iter,'Synthetic CGMY');
%%
%MKT -- extra/interpolation with SVI of the random prices, extraction
%of the best RMSE curve CF and prices. Extraction of cutoff frequency
rng(2)
std_cut = 0.1;           
err_threshold =1e-1;
max_iter=50;
[uc_mkt, CF_ensemble_svi_mkt, cf_best_svi_mkt, IV_best_svi_mkt, prices_best_svi_mkt] = ...
    svi_cf_ensemble_divergence(options_rand_mkt, k_opt, t, k, std_cut, err_threshold,max_iter,'MKT');
%%
%SYNTHETIC BG-- arrival rates comparison for the random prices 
bw = 10^(ceil(log10(dk)));
u_end = uc_synt_BG*5;
damping=-log(10^-4)/u_end^2; 
u_start = u_end*0.1; 
W=tukey_wdw(u,u_start,u_end);
W=1;
[~,~, arr_rates_best_synt_BG]=arrival_rates_ensemble_comparison(CF_ensemble_svi_synt_BG,cf_best_svi_synt_BG, u, t, bw, damping, W, uc_synt_BG,'Synthetic BG',cf_BG_cal);  
plot(x,abs(x).*exact_arr_rate_BG,'r', 'LineWidth', 3,'DisplayName','BG exact formula')
plot(x,abs(x).*arr_rate_BG, 'g-','DisplayName','implied from exact BG cf')
%% 
%approximation results BG
figure
plot(x,log(abs(exact_arr_rate_BG)),'DisplayName','exact BG')
hold on
plot(x,log(abs(arr_rates_best_synt_BG)),'DisplayName','implied')
xline(max(k_opt),'m--','DisplayName',sprintf('max k = %.4f',max(k_opt)))
xline(min(k_opt),'g--','DisplayName',sprintf('min k = %.4f',min(k_opt)))
title('log Arrival Rates')
xlim([-0.2,0.2])
%xlim([-1,1])
ylim([-50,20])
xlabel('x') 
ylabel('log Arrival Rates')
legend('Location','best')
figure
plot(x,abs(exact_arr_rate_BG-arr_rates_best_synt_BG)./abs(exact_arr_rate_BG),'HandleVisibility','off')
hold on
xline(max(k_opt),'m--','DisplayName',sprintf('max k = %.4f',max(k_opt)))
xline(min(k_opt),'g--','DisplayName',sprintf('min k = %.4f',min(k_opt)))
title('Arrival Rates, Relative Error')
xlim([-0.2,0.2])
%xlim([-1,1])
ylim([0,1])
xlabel('x') 
ylabel('|implied-exact|/|exact|')
legend
%%
%SYNTHETIC CGMY -- arrival rates comparison for the random prices 
bw = 10^(ceil(log10(dk)));
u_end = uc_synt_CGMY*5;
damping=-log(10^-4)/u_end^2; 
u_start = u_end*0.1; 
W=tukey_wdw(u,u_start,u_end);
W=1;

[~,~,arr_rates_best_synt_CGMY]=arrival_rates_ensemble_comparison(CF_ensemble_svi_synt_CGMY, cf_best_svi_synt_CGMY, u, t, bw, damping, W, uc_synt_CGMY, 'Synthetic CGMY', cf_CGMY_cal);  
plot(x, abs(x).*exact_arr_rate_CGMY, 'm', 'LineWidth', 3, 'DisplayName', 'CGMY exact formula')
%% 
%approximation results CGMY
figure
plot(x,log(abs(exact_arr_rate_CGMY)),'DisplayName','exact CGMY')
hold on
plot(x,log(abs(arr_rates_best_synt_CGMY)),'DisplayName','implied')
xline(max(k_opt),'m--','DisplayName',sprintf('max k = %.4f',max(k_opt)))
xline(min(k_opt),'g--','DisplayName',sprintf('min k = %.4f',min(k_opt)))
title('log Arrival Rates')
xlim([-0.2,0.2])
%xlim([-1,1])
ylim([-50,20])
xlabel('x') 
ylabel('log Arrival Rates')
legend('Location','best')
figure
plot(x,abs(exact_arr_rate_CGMY-arr_rates_best_synt_CGMY)./abs(exact_arr_rate_CGMY),'HandleVisibility','off')
hold on
xline(max(k_opt),'m--','DisplayName',sprintf('max k = %.4f',max(k_opt)))
xline(min(k_opt),'g--','DisplayName',sprintf('min k = %.4f',min(k_opt)))
title('Arrival Rates, Relative Error')
xlim([-0.2,0.2])
%xlim([-1,1])
ylim([0,1])
xlabel('x') 
ylabel('|implied-exact|/|exact|')
legend
%%
%MKT -- arrival rates comparison for the random prices 
bw = 10^(ceil(log10(dk)));
u_end=uc_mkt*5;
damping=-log(1e-2)/u_end^2; 
u_start =u_end*0.4; 
W=tukey_wdw(u,u_start,u_end);
W=1;

[~,~, arr_rates_best_mkt]=arrival_rates_ensemble_comparison(CF_ensemble_svi_mkt,cf_best_svi_mkt, u, t, bw, damping, W, uc_mkt,'MKT');
%%
%comparison among CF computations with different fft strategies
IV_ATM_svi_synt_BG=IV_best_svi_synt_BG(N/2+1);
cf_imp1=cf_implied_fft(prices_best_svi_synt_BG,k,IV_ATM_svi_synt_BG,t,true,true); %YES discretization, YES adding and subtracting ATM Black prices
cf_imp2=cf_implied_fft(prices_best_svi_synt_BG,k,IV_ATM_svi_synt_BG,t,true,false); %YES discretization, NO adding and subtracting ATM Black prices
cf_imp3=cf_implied_fft(prices_best_svi_synt_BG,k,IV_ATM_svi_synt_BG,t,false,true); %NO discretization, YES adding and subtracting ATM Black prices
cf_imp4=cf_implied_fft(prices_best_svi_synt_BG,k,IV_ATM_svi_synt_BG,t,false,false); %NO discretization, NO adding and subtracting ATM Black prices

figure
plot(u,abs(cf_BG_cal),'m','DisplayName','Original BG CF','LineWidth',3)
hold on
plot(u,abs(cf_imp4),'g','DisplayName','NO discretization, NO ATM Black prices')
plot(u,abs(cf_imp1),'r','DisplayName','YES discretization, YES ATM Black prices','LineWidth',1.5)
plot(u,abs(cf_imp2),'b','DisplayName','YES discretization, NO ATM Black prices','LineWidth',1.5)
plot(u,abs(cf_imp3),'k','DisplayName','NO discretization, YES ATM Black prices','LineWidth',1.5)
title('Comparison among |CF| computations with fft strategies')
xlabel('u')
ylabel('|CF|')
xlim([-50000,50000])
ylim([-0.05,1.05])
legend
%%
format long
RMSE_1=rmse(cf_imp1,cf_BG_cal);
RMSE_2=rmse(cf_imp2,cf_BG_cal);
RMSE_3=rmse(cf_imp3,cf_BG_cal);
RMSE_4=rmse(cf_imp4,cf_BG_cal);
RMSE_all=[RMSE_1,RMSE_2,RMSE_3,RMSE_4]
[normINF_1,idx_inf_1]=max(abs(abs(cf_BG_cal)-abs(cf_imp1)));
u_inf_1=u(idx_inf_1);
[normINF_2,idx_inf_2]=max(abs(abs(cf_BG_cal)-abs(cf_imp2)));
u_inf_2=u(idx_inf_2);
[normINF_3,idx_inf_3]=max(abs(abs(cf_BG_cal)-abs(cf_imp3)));
u_inf_3=u(idx_inf_3);
[normINF_4,idx_inf_4]=max(abs(abs(cf_BG_cal)-abs(cf_imp4)));
u_inf_4=u(idx_inf_4);
norm_INF_all=[normINF_1,normINF_2,normINF_3,normINF_4]
u_norm_INF_all=[u_inf_1,u_inf_2,u_inf_3,u_inf_4]
UF_BG=find_cf_underflow(cf_BG_cal,u);
UF_1=find_cf_underflow(cf_imp1,u);
UF_2=find_cf_underflow(cf_imp2,u);
UF_3=find_cf_underflow(cf_imp3,u);
UF_4=find_cf_underflow(cf_imp4,u);
%%
%SYNTHETIC BG-- arrival rates, 4 plots
u_end=uc_synt_BG*7;
u_start = u_end*[0.1 0.2 0.5]; %Tukey window starting point 
colors=[
    1.00, 0.50, 0.00;
    0.00, 0.00, 1.00; 
    0.00, 0.00, 0.00   
];
for jj=1:length(u_start)+1
    if jj<=length(u_start)     
        W=tukey_wdw(u,u_start(jj),u_end);
    else 
        W=1; % no Tukey window
    end
bw = 10^(ceil(log10(dk)));
damping=[0,-log(10.^-[2:2:6])/u_end^2]; %at u_end the damping factor reaches the argument of the logarithm; =0 means no damping
figure
for ii=1:length(damping)
[arr_rate_synt_BG, x] = arrival_rates(cf_best_svi_synt_BG, u, t, bw,damping(ii),W);
    if jj<=length(u_start)
        Plot=plot(x, abs(x).*arr_rate_synt_BG,'DisplayName', sprintf('damping= %.2e, u_{start}= %.2e',damping(ii),u_start(jj)));
    elseif jj>length(u_start) & ii>1 
        Plot=plot(x, abs(x).*arr_rate_synt_BG,'DisplayName', sprintf('damping= %.2e, no Tukey window',damping(ii)));
    else
        continue;
    end
    if ii==1 % damping=0 causes big oscillations
        Plot.Color=[0.6, 0.6, 0.6, 0.15];
    else
        Plot.Color=colors(ii-1,:);
    end
xlim([-0.05, 0.05])
ylim([-10,50])
hold on 
end 
plot(x,abs(x).*exact_arr_rate_BG,'r', 'LineWidth', 3,'DisplayName','BG exact formula')
plot(x,abs(x).*arr_rate_BG, 'g-','DisplayName','implied from exact BG cf')
title(sprintf('Synthetic BG: Arrival Rates comparison, bw= %.2e, u_{end}= %.2e, uc= %.2e',bw,u_end,uc_synt_BG))
xlabel('x') 
ylabel('Arrival Rates * |x|')
grid on
xlim([-0.05,0.05])
ylim([-10,70])
%plot(x,abs(x).* arr_rate_VGSA, 'k--','DisplayName','VGSA througth paper algorithm')
legend('show','Location', 'northwest'); 
end
%%
%MKT --arrival rates, 4 plots
u_end=uc_mkt*5;
u_start = uc_mkt*[0 0.4 1]; %Tukey window starting point
for jj=1:length(u_start)+1
    if jj<=length(u_start)    
        W=tukey_wdw(u,u_start(jj),u_end);
    else 
        W=1; % no Tukey window
    end
    bw = 10^(ceil(log10(dk)));
    damping=[0,-log(10.^-[2:2:6])/u_end^2]; %at u_end the damping factor reaches the argument of the logarithm; =0 means no damping
    figure
    for ii=1:length(damping)
        [arr_rate_mkt, x] = arrival_rates(cf_best_svi_mkt, u, t, bw,damping(ii),W);
        if jj<=length(u_start)
            Plot=plot(x, abs(x).*arr_rate_mkt,'DisplayName', sprintf('damping= %.2e, u_start= %.2e',damping(ii),u_start(jj)));
        else
            Plot=plot(x, abs(x).*arr_rate_mkt,'DisplayName', sprintf('damping= %.2e, no Tukey window',damping(ii)));
        end
        if ii==1 % damping=0 causes big oscillations
            Plot.Color=[0.6, 0.6, 0.6, 0.15];
        end
        xlim([-0.05, 0.05])
        ylim([-10,50])
        hold on 
    end  
    plot(x,abs(x).*exact_arr_rate_BG,'r', 'LineWidth', 2,'DisplayName','BG exact formula')
    plot(x,abs(x).*arr_rate_BG, 'g-','DisplayName','BG througth paper algorithm')
    title(sprintf('MKT: Arrival Rates comparison, bw= %.2e, uc= %.2e',bw,uc_mkt))
    xlabel('x') 
    ylabel('Arrival Rates * |x|')
    grid on
    plot(x,abs(x).* arr_rate_VGSA, 'k--','DisplayName','VGSA througth paper algorithm')
    legend('show','Location', 'northwest'); 
end
%% 
%density extraction from CF
density=probability_density(cf_best_svi_mkt,du); %returns density
figure
plot(x,density)
hold on
neg=find(density<0); %negativity density indexes 
plot(x(neg),density(neg),'or','MarkerSize',5)
xlim([-0.5,0.5])
title('Density from implied CF.')
legend('Density', 'Negative density points')
xlabel('Returns')
ylabel('Density')
%%
u_eval=1000;
norm_impCF_eval=abs(cf_implied_trapz(prices_best_svi_mkt,k,u_eval)); %check the norm of the implied CF in u=100
fprintf('Implied CF in u=%.4f: %.4f\n\n',u_eval, norm_impCF_eval)
u_grid=2:2:u_eval; %valuation grid of frequencies for Bochner's condition
len_u_grid=length(u_grid);
[uj,ui]=meshgrid(u_grid,u_grid);
u_Herm=ui-uj;
%A_flat=cf_implied_trapz(prices_BG_svi,x,u_Herm); %it takes too much time
IV_ATM_svi_mkt=IV_best_svi_mkt(N/2+1);
A_flat_fft=cf_implied_fft(prices_best_svi_mkt,k,IV_ATM_svi_mkt,t,true,true);
A_flat=interp1(u,A_flat_fft,u_Herm(:));
A=reshape(A_flat,len_u_grid,len_u_grid); %Hermitian matrix
eigenvalues=sort(real(eig(A)),'descend');
fprintf('Top 10 eigenvalues:')
eig_top10=eigenvalues(1:10)
fprintf('Eigenvalues smaller than -1bp:')
eig_neg_relevant=eigenvalues(eigenvalues<-1e-4)
%%
x_max=min(abs(x(neg))); %smallest absolute value of x with negative density
if ~isempty(x_max)
idx_subint=(x>=-x_max)&(x<=x_max); %index of subinterval without negative density
x_subint=x(idx_subint);
density_subint=density(idx_subint); %truncated density

cdf_num=cumtrapz(density_subint); %CDF numerator
cdf_subint=cdf_num/cdf_num(end); %CDF
[cdf_invert,idx_cdf_invert]=unique(cdf_subint,"stable"); %remove flat points to make the CDF invertible
x_cdf_invert=x_subint(idx_cdf_invert);
rng(4);
Nsim=1e4; %number of simulations
Urv=rand(Nsim,1); %uniform random variable in [0,1]
x_sim=interp1(cdf_invert,x_cdf_invert,Urv,"linear","extrap"); %simulated returns

figure
histogram(x_sim,'Normalization', 'pdf')
hold on
dx=x(2)-x(1);
plot(x_subint,density_subint/(cdf_num(end)*dx),'r')
title('Simulated points from rescaled cut density.')
legend('Simulated points', 'Original density')
xlabel('Returns')
ylabel('Density')

N_emp=2^16;
u_emp=[-N_emp/2:N_emp/2-1]*du;
cf_emp_num=zeros(1,N_emp); %initializing empirical CF
block_u = 5000; 
for j = 1:block_u:N_emp %to avoid RAM error
    idx_end = min(j + block_u - 1, N_emp);
    u_block = u_emp(j:idx_end); 
    cf_emp_num(j:idx_end) = sum(exp(1i * (x_sim(:) * u_block(:).')), 1);
end
cf_emp=cf_emp_num/Nsim; %empirical CF

figure
plot(u_emp,abs(cf_emp))
title('Truncated density empirical |CF|')
xlabel('u')
ylabel('|CF|')

u_end=uc_mkt*5;
bw = 10^(ceil(log10(dk)));
damping=-log(1e-10)/u_end^2;
[arr_rate_cf_emp,x_emp]=arrival_rates(cf_emp,u_emp,t,bw,damping); %arrival rate from empirical CF
[arr_rate_mkt,x]=arrival_rates(cf_best_svi_mkt,u,t,bw,damping);

figure
plot(x_emp,abs(x_emp).*arr_rate_cf_emp,'m','DisplayName','Truncated density empirical CF arrival rates')
hold on
plot(x,abs(x).*arr_rate_mkt,'b','DisplayName','BG implied CF arrival rates')
plot(x,abs(x).*exact_arr_rate_BG,'r', 'LineWidth', 2,'DisplayName','BG exact formula')
plot(x,abs(x).*arr_rate_BG, 'g-','DisplayName','BG througth paper algorithm')
title(sprintf('Arrival Rates comparison, bw= %.2e, damping= %.2e',bw,damping))
grid on
plot(x,abs(x).* arr_rate_VGSA, 'k--','DisplayName','VGSA througth paper algorithm')
legend('show','Location', 'northwest'); 
xlim([-0.05, 0.05])
ylim([-10,50])
xlabel('Returns')
ylabel('Arrival Rates')
end
%% DENSITIES ASSOCIATED WITH NEGATIVE ARRIVAL RATE FUNCTIONS 
clear 
N=2^12;
du=1e-1;
u=(-N/2:N/2-1)*du;
a=1;
theta=1;
Gamma=1;
cf_svg_cos=cf_svgcos(u,a,theta,Gamma);
[density_svg_cos,x]=probability_density(cf_svg_cos,du);
figure
plot(x,density_svg_cos,'LineWidth',2)
xlim([-2,2])
title('Density of SVG with cosine perturbation')
xlabel('returns')
ylabel('density')
%%
N=2^12;
du=1e-1;
u=(-N/2:N/2-1)*du;
c=1;
a=[0.25,0.5,1.0];
figure
for ii=1:length(a)
cf_truncsvg=cf_trunc_svg(u,a(ii),c);
[density_truncsvg,x]=probability_density(cf_truncsvg,du);
subplot(3,1,ii)
plot(x,density_truncsvg,'LineWidth',2)
title(sprintf('Truncated SVG with cosine perturbation density, c=1, a= %.2e',a(ii)))
xlim([-2,2])
xlabel('returns')
ylabel('density')
end
%% LEVY RATIO CALIBRATION RESULTS 
clear 
%PUT_all=readtable("Put02_10matt.xlsx"); %maturity 7dd
%CALL_all=readtable("Call02_10mat7.xlsx");
%PUT_all=readtable("Put02_10mat10.xlsx"); %maturity 10dd
%CALL_all=readtable("Call02_10mat10.xlsx");
PUT_all=readtable("Put02_10mat11.xlsx"); %maturity 11dd
CALL_all=readtable("Call02_10mat11.xlsx");
%PUT_all=readtable("Put02_11mat11.xlsx",'VariableNamingRule','preserve'); %maturity 11dd
%CALL_all=readtable("Call02_11mat11.xlsx",'VariableNamingRule','preserve');
%PUT_all=readtable("Put03_11mat14.xlsx",'VariableNamingRule','preserve'); %maturity 14dd
%CALL_all=readtable("Call03_11mat14.xlsx",'VariableNamingRule','preserve');

cleanCol=@(x)str2double(strrep(strrep(string(x),',',''),'-','NaN'));
PUT_all.Bid=cleanCol(PUT_all.Bid);
PUT_all.Ask=cleanCol(PUT_all.Ask);
PUT_all.Strike=cleanCol(PUT_all.Strike);
PUT_all.Volume=cleanCol(PUT_all.Volume);
CALL_all.Bid=cleanCol(CALL_all.Bid);
CALL_all.Ask=cleanCol(CALL_all.Ask);
CALL_all.Strike=cleanCol(CALL_all.Strike);
CALL_all.Volume=cleanCol(CALL_all.Volume);
PUT_all=sortrows(PUT_all,'Strike','ascend');
CALL_all=sortrows(CALL_all,'Strike','ascend');

t=CALL_all.Maturity(1)/365; %ttm
max_rel_spread=0.8; 
mid_put_all=(PUT_all.Bid+PUT_all.Ask)/2;
spread_put=PUT_all.Ask-PUT_all.Bid;
cond_put=(PUT_all.Volume>15)&(PUT_all.Bid>0)&...
    (PUT_all.Ask>PUT_all.Bid)&((spread_put./mid_put_all)<max_rel_spread);%filtering wrt volume and bidask
PUT=PUT_all(cond_put,:);
mid_call_all=(CALL_all.Bid+CALL_all.Ask)/2;
spread_call=CALL_all.Ask-CALL_all.Bid;
cond_call=(CALL_all.Volume>15)&(CALL_all.Bid>0)&...
    (CALL_all.Ask>CALL_all.Bid)&((spread_call./mid_call_all)<max_rel_spread);
CALL=CALL_all(cond_call,:);

[K_cntr,idx_CALL,idx_PUT]=intersect(CALL.Strike,PUT.Strike,'sorted');%indexes of strikes in both Call and Put tables
PUT_cntr=PUT(idx_PUT,:); 
CALL_cntr=CALL(idx_CALL,:);
put_mid_cntr=(PUT_cntr.Bid+PUT_cntr.Ask)/2;  %mid price
call_mid_cntr=(CALL_cntr.Bid+CALL_cntr.Ask)/2;
[B,F]=disc_and_fwd(K_cntr,put_mid_cntr,call_mid_cntr,t); %B:discount factor, F:forward

PUT_OTM=PUT(PUT.Strike<=F,:); %OTM wrt F filtering
CALL_OTM=CALL(CALL.Strike>=F,:);
k_put=log(PUT_OTM.Strike/F);
k_call=log(CALL_OTM.Strike/F);
k_opt=[k_put;k_call]; %log(strike/F)
call_ask=CALL_OTM.Ask/(B*F);
call_bid=CALL_OTM.Bid/(B*F);
put_ask=PUT_OTM.Ask/(B*F);
put_bid=PUT_OTM.Bid/(B*F);
options_ask=[put_ask;call_ask];
options_bid=[put_bid;call_bid];
options_mid=(options_bid+options_ask)/2;%mid price normalized wrt B and F

N=2^16;          
du=0.1;          
u=(-N/2:N/2-1)*du;
u_max=du*N/2;
dk=2*pi/(N*du);
k_max=dk*N/2;
k=(-N/2:N/2-1)*dk;
%%
options_lsq=optimoptions('lsqnonlin',...
    'Display','off',...
    'MaxFunctionEvaluations',10000,...
    'MaxIterations',3000,...
    'StepTolerance',1e-8,...         
    'FunctionTolerance',1e-8,...     
    'OptimalityTolerance',1e-8);

RMSE_results=struct();

run_calib=@(name,x0,lb,ub)lsqnonlin(...
    @(p)obj_free(p,k_opt,t,u,options_mid,name),...
    x0,lb,ub,options_lsq);

fprintf('\n======================================================\n');
fprintf('BG CALIBRATION\n');
fprintf('======================================================\n');
lb_BG=[1e-3,0.1,1e-3,0.1]; 
ub_BG=[0.5,10000,0.8,100];
x0_BG=[0.04,62.16,0.32,3.72]; % [bp,cp,bn,cn];
[opt_BG,~,resid_BG]=run_calib('BG',x0_BG,lb_BG,ub_BG);
RMSE_results.BG=sqrt(mean(resid_BG.^2));

fprintf('\n======================================================\n');
fprintf('CGMY CALIBRATION\n');
fprintf('======================================================\n');
lb_CGMY=[1e-4,-1,1e-4,1e-4,-1,1e-4];
ub_CGMY=[100,1.9,5,100,1.9,5];
x0_CGMY=[1,0.5,0.1,1,0.5,0.1]; 
[opt_CGMY,~,resid_CGMY]=run_calib('CGMY',x0_CGMY,lb_CGMY,ub_CGMY);
RMSE_results.CGMY=sqrt(mean(resid_CGMY.^2));

fprintf('\n======================================================\n');
fprintf('DENOMINATOR STARTING VALUES (Ratio Models)\n');
fprintf('======================================================\n');
vols=[0.025,0.05]; 
kurts=[5,10,15];  
best_rmse_BGR=inf;
best_x0_BGR=[];
best_rmse_CGMYR=inf;
best_x0_CGMYR=[];

for s=vols
    for K=kurts
        c_d_bg=3/(K-3); % BG
        b_d_bg=sqrt((s^2)/(2*c_d_bg));
        denom_BG=[b_d_bg,c_d_bg,b_d_bg,c_d_bg];
        
        x0_test_BGR=[opt_BG,denom_BG];
        res_test_BGR=obj_free(x0_test_BGR,k_opt,t,u,options_mid,'BGR');
        rmse_BGR=sqrt(mean(res_test_BGR.^2));
        
        if rmse_BGR<best_rmse_BGR
            best_rmse_BGR=rmse_BGR;
            best_x0_BGR=x0_test_BGR;
        end
        
        y_d_cgmy=0.5; % we fix activity for CGMY
        b_d_cgmy=sqrt(((K-3)*s^2)/(gamma(4-y_d_cgmy)*gamma(2-y_d_cgmy)));
        c_d_cgmy=(s^2)/(2*(b_d_cgmy^(2-y_d_cgmy))*gamma(2-y_d_cgmy));
        denom_CGMY=[c_d_cgmy,y_d_cgmy,b_d_cgmy,c_d_cgmy,y_d_cgmy,b_d_cgmy];
        
        x0_test_CGMYR=[opt_CGMY,denom_CGMY];
        res_test_CGMYR=obj_free(x0_test_CGMYR,k_opt,t,u,options_mid,'CGMYR');
        rmse_CGMYR=sqrt(mean(res_test_CGMYR.^2));
        
        if rmse_CGMYR<best_rmse_CGMYR
            best_rmse_CGMYR=rmse_CGMYR;
            best_x0_CGMYR=x0_test_CGMYR;
        end
    end
end
fprintf('BGR best starting values with RMSE: %.6f\n',best_rmse_BGR);
fprintf('CGMY best starting value with RMSE: %.6f\n',best_rmse_CGMYR);

fprintf('\n======================================================\n');
fprintf('BGR CALIBRATION\n');
fprintf('======================================================\n');
lb_BGR=[lb_BG,lb_BG]; 
ub_BGR=[ub_BG,ub_BG];

[opt_BGR,~,resid_BGR]=run_calib('BGR',best_x0_BGR,lb_BGR,ub_BGR);
RMSE_results.BGR=sqrt(mean(resid_BGR.^2));

fprintf('\n======================================================\n');
fprintf('CGMYR CALIBRATION\n');
fprintf('======================================================\n');
lb_CGMYR=[lb_CGMY,lb_CGMY];
ub_CGMYR=[ub_CGMY,ub_CGMY];

[opt_CGMYR,~,resid_CGMYR]=run_calib('CGMYR',best_x0_CGMYR,lb_CGMYR,ub_CGMYR);
RMSE_results.CGMYR=sqrt(mean(resid_CGMYR.^2));

fprintf('\n======================================================\n');
fprintf('MODELS RMSE\n');
fprintf('======================================================\n');
disp(RMSE_results);

price_BG=options_mid+resid_BG; % model prices
price_CGMY=options_mid+resid_CGMY;
price_BGR=options_mid+resid_BGR;
price_CGMYR=options_mid+resid_CGMYR;

figure
plot(k_opt,options_mid,'ko','MarkerFaceColor','k','DisplayName','Market Mid-Price')
hold on
plot(k_opt,price_BG,'b-','LineWidth',1.5,'DisplayName','BG')
plot(k_opt,price_CGMY,'g-','LineWidth',1.5,'DisplayName','CGMY')
plot(k_opt,price_BGR,'r--','LineWidth',1.5,'DisplayName','BGR')
plot(k_opt,price_CGMYR,'m--','LineWidth',1.5,'DisplayName','CGMYR')
xlabel('k')
ylabel('Price')
title('Models Calibration')
legend('Location','best')
grid on
%%
% errors and prices plots
K_opt=[PUT_OTM.Strike;CALL_OTM.Strike]; % strikes

ape_BG=abs(resid_BG./options_mid)*100;
ape_CGMY=abs(resid_CGMY./options_mid)*100;
ape_BGR=abs(resid_BGR./options_mid)*100;
ape_CGMYR=abs(resid_CGMYR./options_mid)*100;

figure
plot(K_opt,ape_BG,'bo','MarkerFaceColor','b','DisplayName','BG')
hold on
plot(K_opt,ape_BGR,'ro','MarkerFaceColor','r','DisplayName','BGR')
plot(K_opt,ape_CGMY,'ko','MarkerFaceColor','k','DisplayName','CGMY')
plot(K_opt,ape_CGMYR,'mo','MarkerFaceColor','m','DisplayName','CGMYR')
xlabel('Strike')
ylabel('APE')
title('Absolute Percentage Errors')
legend('Location','best')
grid on;

figure
plot(K_opt,log(options_mid),'bo','DisplayName','Market')
hold on
plot(K_opt,log(price_BG),'r*','DisplayName','BG')
plot(K_opt,log(price_BGR),'k+','DisplayName','BGR')
plot(K_opt,log(price_CGMYR),'k.','MarkerSize',10,'DisplayName','CGMYR')
xlabel('Strike')
ylabel('log(price)')
title('Log Option Prices')
legend('Location','best')
grid on;
%%
% log arrival rates
x_levy=linspace(-0.1,0.1,1000); 
x_levy(abs(x_levy)<1e-6)=1e-5; 

bgr_num=zeros(size(x_levy));
bgr_den=zeros(size(x_levy));
cgmyr_num=zeros(size(x_levy));
cgmyr_den=zeros(size(x_levy));
bg_eff=zeros(size(x_levy));
cgmy_eff=zeros(size(x_levy));

idx_p=x_levy>0;
idx_n=x_levy<0;

arr_rates_BG_p=@(x,p,idx)(p(2).*exp(-x(idx)./p(1))./x(idx)); % [bp, cp, bn, cn] 
arr_rates_BG_n=@(x,p,idx)(p(4).*exp(-abs(x(idx))./p(3))./abs(x(idx)));

bgr_num(idx_p)=arr_rates_BG_p(x_levy,opt_BGR(1:4),idx_p);
bgr_num(idx_n)=arr_rates_BG_n(x_levy,opt_BGR(1:4),idx_n);
bgr_den(idx_p)=arr_rates_BG_p(x_levy,opt_BGR(5:8),idx_p);
bgr_den(idx_n)=arr_rates_BG_n(x_levy,opt_BGR(5:8),idx_n);
bg_eff(idx_p)=arr_rates_BG_p(x_levy,opt_BG,idx_p);
bg_eff(idx_n)=arr_rates_BG_n(x_levy,opt_BG,idx_n);

arr_rates_CGMY_p=@(x,p,idx)(p(1).*exp(-x(idx)./p(3))./(x(idx).^(1+p(2))));% [cp, yp, bp, cn, yn, bn]
arr_rates_CGMY_n=@(x,p,idx)(p(4).*exp(-abs(x(idx))./p(6))./(abs(x(idx)).^(1+p(5))));

cgmyr_num(idx_p)=arr_rates_CGMY_p(x_levy,opt_CGMYR(1:6),idx_p);
cgmyr_num(idx_n)=arr_rates_CGMY_n(x_levy,opt_CGMYR(1:6),idx_n);
cgmyr_den(idx_p)=arr_rates_CGMY_p(x_levy,opt_CGMYR(7:12),idx_p);
cgmyr_den(idx_n)=arr_rates_CGMY_n(x_levy,opt_CGMYR(7:12),idx_n);
cgmy_eff(idx_p)=arr_rates_CGMY_p(x_levy,opt_CGMY,idx_p);
cgmy_eff(idx_n)=arr_rates_CGMY_n(x_levy,opt_CGMY,idx_n);

bgr_eff=bgr_num-bgr_den;
cgmyr_eff=cgmyr_num-cgmyr_den;
bgr_eff(bgr_eff<=0)=NaN; % to avoid log ignores Imaginary part
cgmyr_eff(cgmyr_eff<=0)=NaN;

figure
subplot(2,2,1)
plot(x_levy,log(bgr_num),'b-','LineWidth',1.5,'DisplayName','Numerator') 
hold on
plot(x_levy,log(bgr_den),'r-','LineWidth',1.5,'DisplayName','Denominator')
xlabel('Returns')
ylabel('Log Levy Density')
title('BGR Num and Den Densities')
grid on
legend('Location','best')

subplot(2,2,2)
plot(x_levy,log(cgmyr_num),'b-','LineWidth',1.5,'DisplayName','Numerator')
hold on
plot(x_levy,log(cgmyr_den),'r-','LineWidth',1.5,'DisplayName','Denominator')
xlabel('Returns')
ylabel('Log Levy Density')
title('CGMYR Num and Den Densities')
grid on
legend('Location','best')

subplot(2,2,3)
plot(x_levy,log(bg_eff),'b-','LineWidth',1.5,'DisplayName','BG')
hold on
plot(x_levy,log(bgr_eff),'r-','LineWidth',1.5,'DisplayName','BGR')
xlabel('Returns')
ylabel('Log Levy Density')
title('BG and BGR Densities')
grid on
legend('Location','best')

subplot(2,2,4)
plot(x_levy,log(cgmy_eff),'b-','LineWidth',1.5,'DisplayName','CGMY')
hold on
plot(x_levy,log(cgmyr_eff),'r-','LineWidth',1.5,'DisplayName','CGMYR')
xlabel('Returns')
ylabel('Log Levy Density')
title('CGMY and CGMYR Densities')
grid on
legend('Location','best')